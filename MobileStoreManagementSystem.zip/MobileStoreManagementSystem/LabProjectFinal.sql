Create Database MobileStoredb;
use MobileStoredb;

Create Table tblUsers
(
UID int identity(600,1) primary key,
UserName varchar(50),
UPass varchar(20) ,
isAdmin varchar(6)
);
Insert into tblUsers values('ahmedkhan@gmail.com','123','true');
Insert into tblUsers values('kashifali@gmail.com','456','false');
Insert into tblUsers values('tanveer@yahoo.com','789','true');
Insert into tblUsers values('iqbalahmed@hotmail.com','1011','false');
Insert into tblUsers values('ziaudin@outlook.com','1213','true');
Insert into tblUsers values('zubairali@zoho.com','1415','true');
Insert into tblUsers values('ahmedkhan@protonmail.com','1617','false');
Select * from tblUsers;



Create Table tblMobileStore1
(

MID int identity(600,1) primary key,
CustomerName varchar(50),
PhoneNo varchar(20) unique,
MobileName varchar(15),
Price int,
ModelNo varchar(20),
Bluetooth varchar(6),
FMRadio varchar(6),
Camera varchar(6),
WiFi varchar(6)
);


Insert into tblMobileStore1 values ('Mr.Ahmed Khan','0300-1234567','NOKIA 3310',5200,'AB-3310','NO','YES','NO','NO');
Insert into tblMobileStore1 values ('Mr.Kashif Ali','0333-1234567','NOKIA E-90',8600,'XY-3310','NO','YES','NO','NO');
Insert into tblMobileStore1 values ('Mr.Tanveer','0345-1234567','NOKIA N-70',9100,'ZS-N70','NO','YES','YES','YES');
Insert into tblMobileStore1 values ('Mr.Iqbal Ahmed','0321-1234567','Samsung-Note1',18000,'NOTE-1550','YES','YES','YES','YES');
Insert into tblMobileStore1 values ('Mr.Ziauddin','0332-1234567','Samsung-Note2',22000,'NOTE-1650','YES','YES','YES','YES');
Insert into tblMobileStore1 values ('Mr.Zubair Ali','0334-1234567','Apple-iPhone4S',17500,'Digit-4S','YES','NO','YES','NO');
Insert into tblMobileStore1 values ('Mr.Intizaar','0335-1234567','Apple-iPhone5S',21000,'Digit-5S','YES','NO','YES','NO');

Select * from tblMobileStore1;






Create Table tblMobileData
(

PID int identity(1,1) primary key,
MobileName varchar(20),
Price int,
ModelNo varchar(10),
Bluetooth varchar(10),
FMRadio varchar(10),
Camera varchar(10),
WiFi varchar(10)

);
Insert into tblMobileData values ('NOKIA 3310',5200,'AB-3310','NO','YES','NO','NO');
Insert into tblMobileData values ('NOKIA E-90',8600,'XY-3310','NO','YES','NO','NO');
Insert into tblMobileData values ('NOKIA N-70',9100,'ZS-N70','NO','YES','YES','YES');
Insert into tblMobileData values ('Samsung-Note1',18000,'NOTE-1550','YES','YES','YES','YES');
Insert into tblMobileData values ('Samsung-Note2',22000,'NOTE-1650','YES','YES','YES','YES');
Insert into tblMobileData values ('Apple-iPhone4S',17500,'Digit-4S','YES','NO','YES','NO');
Insert into tblMobileData values ('Apple-iPhone5S',21000,'Digit-5S','YES','NO','YES','NO');

Select * from tblMobileData;




Create Table tblStock
(
SID int identity(1,1) primary key,
MobileName varchar(20),
Price int,
ModelNo varchar(10),
Bluetooth varchar(10),
FMRadio varchar(10),
Camera varchar(10),
WiFi varchar(10),
Pieces int
);

Insert into tblStock values ('NOKIA 3310',5200,'AB-3310','NO','YES','NO','NO',5);
Insert into tblStock values ('NOKIA E-90',8600,'XY-3310','NO','YES','NO','NO',4);

Select * from  tblStock;


