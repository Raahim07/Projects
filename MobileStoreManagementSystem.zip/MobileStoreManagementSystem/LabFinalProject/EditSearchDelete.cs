﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabFinalProject
{
    public partial class EditSearchDelete : Form
    {
        private SqlConnection xConn;
        public EditSearchDelete()
        {
            InitializeComponent();
            xConn = new SqlConnection("Server = DESKTOP-P5QIQDQ; Database = MobileStoredb; UID = sa; PWD = 123;");
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }

        //private void btnDelete_Click(object sender, EventArgs e)
        //{
        //    DataTable xTable = new DataTable();
        //    DialogResult DR = MessageBox.Show("Are you sure to delete?", "Error", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        //    if (DR == DialogResult.Yes)
        //    {
        //        new SqlDataAdapter("Delete from tblMobileStore1 Where MID = '" + txtID.Text + "'", xConn).Fill(xTable);
        //        new SqlDataAdapter("Delete from tblUsers Where UID = '" + txtID.Text + "'", xConn).Fill(xTable);
        //    }
        //    txtID.Text = null;

            
        //    new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
        //    xGrid.DataSource = xTable;
        //}

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable xTable = new DataTable();
            String query = "Select * from tblMobileStore1 Where MID = '" + txtID.Text + "'";

            new SqlDataAdapter(query, xConn).Fill(xTable);
            xGrid.DataSource = xTable;

            
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }

        private void xGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {

                int id = Convert.ToInt32(xGrid.Rows[e.RowIndex].Cells["MID"].FormattedValue.ToString());
                xConn.Open();
                new SqlCommand("Delete from tblMobileStore1 Where MID='" + id + "'", xConn).ExecuteNonQuery();
                xConn.Close();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
                xGrid.DataSource = xTable;//do something
            }
        }

      

       
    }
}
