﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabFinalProject
{
    public partial class MobileSales : Form
    {
        private SqlConnection xConn;
        public MobileSales()
        {
            InitializeComponent();
            xConn = new SqlConnection("Server=DESKTOP-P5QIQDQ; Database=MobileStoredb; UID=sa; PWD=123;");
            FillGrid();
            FillPhone();
        }
        private void FillGrid()
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            xConn.Open();
            new SqlCommand("Insert into tblMobileStore1 values ('" + txtCustName.Text + "','" + txtPhoneNo.Text + "','" + cmbMobileName.Text + "','"+txtPrice.Text+"','"+ txtModelNo.Text+"','"+txtBluetooth.Text+"','"+txtFM.Text+"','"+txtCam.Text+"','"+txtWiFi.Text+"')", xConn).ExecuteNonQuery();
            xConn.Close();
            MessageBox.Show("Data saved successfully in Database!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtCustName.Text = txtPhoneNo.Text = cmbMobileName.Text = txtPrice.Text= txtModelNo.Text = txtBluetooth.Text = txtFM.Text = txtCam.Text = txtWiFi.Text = null;
            FillGrid();
        }

        private void FillPhone() //Method-01
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select MobileName, Price from tblMobileData", xConn).Fill(xTable);
            cmbMobileName.DataSource = xTable;
            cmbMobileName.DisplayMember = "MobileName";
            cmbMobileName.ValueMember = "Price";            
        }

        private void cmbMobileName_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblMobileData Where MobileName='"+cmbMobileName.Text+"'", xConn).Fill(xTable);
            txtPrice.Text = xTable.Rows[0][2].ToString();
            txtModelNo.Text = xTable.Rows[0][3].ToString();
            txtBluetooth.Text = xTable.Rows[0][4].ToString();
            txtFM.Text = xTable.Rows[0][5].ToString();
            txtCam.Text = xTable.Rows[0][6].ToString();
            txtWiFi.Text = xTable.Rows[0][7].ToString();
                     
        }

        private void txtTotal_MouseClick(object sender, MouseEventArgs e)
        {
            txtTotal.Text = Convert.ToString(Convert.ToInt32(txtQty.Text) * Convert.ToInt32(txtPrice.Text));
        }

      
     
    }
}
