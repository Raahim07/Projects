﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabFinalProject
{
    public partial class Form1 : Form
    {

        private SqlConnection xConn;
        public Form1()
        {
            InitializeComponent();
            txtUserName.Select();
            xConn = new SqlConnection("Server = DESKTOP-P5QIQDQ; Database = MobileStoredb; UID = sa; PWD = 123;");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                xConn.Dispose();
                Application.Exit();
           
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblUsers Where UserName ='"+txtUserName.Text+"' and UPass = '"+txtPassword.Text+"'",xConn).Fill(xTable);

            if (xTable.Rows.Count > 0)
            {
                this.Hide();
                bool A = bool.Parse(xTable.Rows[0][3].ToString()); //True/False.
                new Menu(A).Show();      
            }
            else 
            {
                MessageBox.Show("Invalid credentials!" ,"Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPassword.Text = null;
                txtUserName.Text = null;
            
            }
        }

        private void cbShow_Hide_CheckedChanged(object sender, EventArgs e)
        {            
            if (cbShow_Hide.Checked)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else 
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }

      

      

    }
}
