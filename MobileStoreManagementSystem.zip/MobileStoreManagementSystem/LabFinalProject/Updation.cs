﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabFinalProject
{
    public partial class Updation : Form
    {
        
        private SqlConnection xConn;
        int MID;
        public Updation()
        {
            InitializeComponent();
            xConn = new SqlConnection("Server=DESKTOP-P5QIQDQ; Database=MobileStoredb; UID=sa; PWD=123;");
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
            xGrid.DataSource = xTable;            
        }
        
        private void xGrid_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MID = Convert.ToInt32(xGrid.Rows[e.RowIndex].Cells[0].Value.ToString());
            txtCustName.Text = xGrid.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtMobName.Text = xGrid.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtPhoneNo.Text = xGrid.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtPrice.Text = xGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtModelNo.Text = xGrid.Rows[e.RowIndex].Cells[5].Value.ToString();
            cmbBluetooth.Text = xGrid.Rows[e.RowIndex].Cells[6].Value.ToString();
            cmbFM.Text = xGrid.Rows[e.RowIndex].Cells[7].Value.ToString();
            cmbCam.Text = xGrid.Rows[e.RowIndex].Cells[8].Value.ToString();
            cmbWiFi.Text = xGrid.Rows[e.RowIndex].Cells[9].Value.ToString();
        }

     

        private void btnClose_Click(object sender, EventArgs e)
        {
            xConn.Dispose();
            this.Dispose();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            xConn.Open();
            new SqlCommand("Update tblMobileStore1 set CustomerName='" + txtCustName.Text + "',PhoneNo='" + txtPhoneNo.Text + "',MobileName='" + txtMobName.Text + "',Price='" + txtPrice.Text.ToString() + "',ModelNo='" + txtModelNo.Text + "',Bluetooth='" + cmbBluetooth.Text + "',FMRadio='" + cmbFM.Text + "',Camera='" + cmbCam.Text + "',WiFi='" + cmbWiFi.Text + "' where MID = '" + MID + "'", xConn).ExecuteNonQuery();
            xConn.Close();
            txtModelNo.Text = txtCustName.Text = txtPhoneNo.Text = txtPrice.Text = cmbBluetooth.Text = cmbCam.Text = cmbFM.Text = cmbWiFi.Text = txtMobName.Text = null;
            MessageBox.Show("Data updated successfully in Database...", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblMobileStore1", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }

    
    }
}
 