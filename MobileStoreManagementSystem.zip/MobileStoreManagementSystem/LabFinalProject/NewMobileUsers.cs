﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabFinalProject
{
    public partial class NewMobileUsers : Form
    {
         private SqlConnection xConn;
        public NewMobileUsers() 
        {
            InitializeComponent();
            xConn = new SqlConnection("Server=DESKTOP-P5QIQDQ; Database=MobileStoredb; UID=sa; PWD=123;");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            xConn.Dispose();
            this.Dispose();
            
        }


        private void btnShow_Click(object sender, EventArgs e)
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblUsers", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {

            if (txtPassword.Text == txtConPassword.Text)
            {

                xConn.Open();
                new SqlCommand("Insert into tblUsers values ('" + txtEmail.Text + "','" + txtPassword.Text + "','"+ cmbAdmin.Text +"')", xConn).ExecuteNonQuery();
                xConn.Close();
                MessageBox.Show("Account created successfully!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtConPassword.Text = txtEmail.Text = txtPassword.Text = null;
            }
            else 
            {
                MessageBox.Show("Check Password!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtConPassword.Text = txtEmail.Text = txtPassword.Text = null;
            
            }

            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblUsers", xConn).Fill(xTable);
            xGrid.DataSource = xTable;

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {

                txtPassword.UseSystemPasswordChar = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                txtConPassword.UseSystemPasswordChar = true;
            }
            else
            {

                txtConPassword.UseSystemPasswordChar = false;
            }
        }

       
    }
}
