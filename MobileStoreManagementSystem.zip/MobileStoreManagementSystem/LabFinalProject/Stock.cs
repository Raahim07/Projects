﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabFinalProject
{
    public partial class Stock : Form
    {
        private SqlConnection xConn;
        public Stock()
        {
            InitializeComponent();
            xConn = new SqlConnection("Server = DESKTOP-P5QIQDQ; Database = MobileStoredb; UID = sa; PWD = 123;");
            FillGrid();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            xConn.Open();
            new SqlCommand("Insert into tblStock values ('" + txtMobName.Text + "','" + txtPrice.Text + "','" + txtModelNo.Text + "','" + cmbBluetooth.Text + "','" + cmbFM.Text + "','" + cmbCam.Text + "','" + cmbWiFi.Text + "','"+ txtPieces.Text +"')", xConn).ExecuteNonQuery();
            new SqlCommand("Insert into tblMobileData values ('" + txtMobName.Text + "','" + txtPrice.Text + "','" + txtModelNo.Text + "','" + cmbBluetooth.Text + "','" + cmbFM.Text + "','" + cmbCam.Text + "','" + cmbWiFi.Text +  "')", xConn).ExecuteNonQuery();
            xConn.Close();
            MessageBox.Show("Data saved successfully in Database!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtMobName.Text = txtPrice.Text = txtModelNo.Text = cmbBluetooth.Text = cmbFM.Text = cmbCam.Text = cmbWiFi.Text = txtPieces.Text  = null;
            FillGrid();
        }

        private void FillGrid()
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblStock", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblStock Where MobileName = '" + txtSearch.Text + "'", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
        }
    }
}
