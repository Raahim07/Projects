﻿using System;
using System.Windows.Forms;

namespace LabFinalProject
{
    public partial class Menu : Form
    {
        public Menu(bool A)
        {
            InitializeComponent();
            mnuRegNewUser.Enabled=A;
            mnuUpdate.Enabled = A;
            mnuEdit.Enabled = A;
            stockToolStripMenuItem.Enabled = A;
        }

        public Menu()
        {

            InitializeComponent();
        
        }

        private void mnuEdit_Click(object sender, EventArgs e)
        {
            new EditSearchDelete().Show();
        }

        private void mnuUpdate_Click(object sender, EventArgs e)
        {
            new Updation().Show();
        }

        private void mnuRegNewUser_Click(object sender, EventArgs e)
        {
            new NewMobileUsers().Show();
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void mobileSalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new MobileSales().Show();
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Stock().Show();
        } 
    }
}
